  <?php session_start();
session_unset();


       ?>    

<script>   

    window.location.href="admin_login.php";
    </script>