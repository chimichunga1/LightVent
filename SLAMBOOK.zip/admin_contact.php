<style>

.space
{
  width: 100%;
  padding: 5%;
}


</style>



<div class="space">


<form class="form-horizontal" method="post" action="admin_submit.php">
  <?php $row=placeholder($conn,'tbl_contact'); ?>
  <div class="form-group">
    <label class=" col-sm-2" >ADDRESS</label>
    <div class="col-sm-10">   <textarea rows="5" class="form-control" name="b" ><?php  echo $row[1]; ?></textarea> </div>
  </div>
   <div class="form-group">
    <label class=" col-sm-2" >PHONE NUMBER</label>
    <div class="col-sm-10">   <input type="text" class="form-control" name="c" <?php  echo "value='".$row[2]."' "; ?>> </div>
  </div>
    <div class="form-group">
    <label class=" col-sm-2" >TELEPHONE NUMBER</label>
    <div class="col-sm-10">   <input type="text" class="form-control" name="d" <?php  echo "value='".$row[3]."' "; ?>> </div>
  </div>
   <div class="form-group">
    <label class=" col-sm-2" >FACEBOOK</label>
    <div class="col-sm-10">   <input type="text" class="form-control" name="e" <?php  echo "value='".$row[4]."' "; ?>> </div>
  </div>
    <div class="form-group">
    <label class=" col-sm-2" >TWITTER</label>
    <div class="col-sm-10">   <input type="text" class="form-control" name="f" <?php  echo "value='".$row[5]."' "; ?>> </div>
  </div>
    <div class="form-group">
    <label class=" col-sm-2" >INSTAGRAM</label>
    <div class="col-sm-10">   <input type="text" class="form-control" name="g" <?php  echo "value='".$row[6]."' "; ?>> </div>
  </div>
    
   
 
  



  <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10">
      <button style="width:100%;" type="submit" name="save_contact" class="btn btn-success">Submit</button>
    </div>
  </div>
</form>
  


  

</div> 