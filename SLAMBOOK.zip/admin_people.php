<?php 

   $que1=mysqli_query($conn,"SELECT * FROM tbl_acc WHERE NOT `u_id`='".$_SESSION['u_id']."'");
   while($ques1=mysqli_fetch_assoc($que1))

{


?>


<div class="col-md-3 col-xs-6">
<div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $ques1['u_id']; ?></h3>
<?php
   $que12=mysqli_query($conn,"SELECT * FROM tbl_personal WHERE `u_id`='".$ques1['u_id']."'");
   $ques12=mysqli_fetch_array($que12);


   $x1="#mod".$ques12[0];
   $x2="mod".$ques12[0];
   	?>

              <p><?php echo $ques12[1] ." ". substr($ques12[2],0,1).". " .$ques12[3]; ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" data-toggle="modal" <?php echo 'data-target="'.$x1.'"';?>  class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
</div>



<!-- Trigger the modal with a button -->


<!-- Modal -->
<div <?php echo 'id="'.$x2.'"'; ?> class="modal modal-info fade in" role="dialog">
  <div class="modal-dialog modal-lg">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><?php echo $ques12[1] ." ". substr($ques12[2],0,1).". " .$ques12[3]; ?></h4>
      </div>
      <div class="modal-body">
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


<?php



}

?>