  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     

      <!--------------------------
        | Your Page Content Here |
        -------------------------->

<?php 




?>
    <?php
    if(isset($_GET['x']))
    {
      if(($_GET['x']) =='Personal')
      {
       include('admin_personal.php');
      }
      elseif (($_GET['x']) =='Favorite')
      {
      include('admin_favorite.php');
      }
      elseif (($_GET['x']) =='Education')
      {
      include('admin_education.php');
      }
      elseif (($_GET['x']) =='Question')
      {
      include('admin_Question.php');
      }
      elseif (($_GET['x']) =='Contact')
      {
      include('admin_contact.php');
      }
      elseif (($_GET['x']) =='About')
      {
      include('admin_about.php');
      }
      elseif (($_GET['x']) =='Security')
      {
      include('admin_security.php');
      }
       elseif (($_GET['x']) =='People')
      {
      include('admin_people.php');
      }
   


      else
      {
            
      }
    }
    else
    {

    }
    ?>



    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  

 
