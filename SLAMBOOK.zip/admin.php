<?php
  session_start();

include('functions.php'); 

include('admin_head.php');
include('admin_main_header.php');
include('admin_sidebar.php');
include('admin_content.php');
include('admin_control_sidebar.php');


?>
 